let submitBtn = document.getElementById("submitBtn")

submitBtn.addEventListener("click", () => {

    event.preventDefault()

    let name = document.getElementById("name").value
    let email = document.getElementById("email").value
    let phone = document.getElementById("phone").value
    let pass = document.getElementById("pass").value
    let cek = document.getElementById("cek")

    if(name.length==0){
        document.getElementById("errorname").style.visibility = "visible";
    }else{
        document.getElementById("errorname").style.visibility = "hidden";
    }

    if(email.endsWith("@gmail.com")==false){
        document.getElementById("erroremail").style.visibility = "visible";
    }else{
        document.getElementById("erroremail").style.visibility = "hidden";
    }

    if(phone.length<12 || phone.length>12){
        document.getElementById("errorphone").style.visibility = "visible";
    }else{
        document.getElementById("errorphone").style.visibility = "hidden";
    }

    if(pass.length==0){
        document.getElementById("errorpass").style.visibility = "visible";
    }else{
        document.getElementById("errorpass").style.visibility = "hidden";
    }

    if(cek.checked != true){
        document.getElementById("errorcek").style.visibility = "visible";
    }else{
        document.getElementById("errorcek").style.visibility = "hidden";
    }
})